# Oi, tudo bem? Chegou aqui através do curso, certo? 🙃

Esse é o repositório da nossa aula de Javascript, na qual vamos fazer um joguinho de space shooter super legal! 

### Os requisitos são:

* [HTML básico](https://www.w3schools.com/html/)
* [CSS básico](https://developer.mozilla.org/pt-BR/docs/Web/CSS)
* [Javascript básico](https://developer.mozilla.org/pt-BR/docs/Web/JavaScript)
 


## 🚀 Let's code! 🚀
